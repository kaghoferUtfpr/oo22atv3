package br.edu.utfpr;

public enum Status {
    DEVOLVIDO("Devolvido"),
    NAODEVOLVIDO("Não Devolvido");

    Status(String devolvido) {
    }
}
