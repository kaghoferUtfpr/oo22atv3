package br.edu.utfpr;

import java.util.ArrayList;
import java.util.List;

public class Bancos {
    public static List<Livro> bancoLivros = new ArrayList<>();
    public static List<Reserva> bancoReservas = new ArrayList<>();
    public static List<Pessoa> bancoPessoas = new ArrayList<>();
}
